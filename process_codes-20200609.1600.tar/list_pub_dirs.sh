#!/bin/bash

mod_exp_camp=/p/user_pub/e3sm/bartoletti1/Model_Experiment_Campaign

pub_head_dir=/p/user_pub/work/E3SM

path_mid=1deg_atm_60-30km_ocean/atmos/native/model-output

for campaign in BGC DECK; do

	model_experiments=`grep $campaign $mod_exp_camp | cut -f1,2 -d,`
 
	for mod_exp in $model_experiments; do

		thisModel=`echo $mod_exp | cut -f1 -d,`
		thisExp=`echo $mod_exp | cut -f2 -d,`

		# find all ensembles
		ensembles=`find $pub_head_dir -type d | grep $thisModel | grep "/$thisExp/" | grep "/ens" | cut -f13 -d/ | sort | uniq`
		
		for ens in $ensembles; do

			for freq in day 6hr_ave 6hr_snap 3hr; do
				# echo "($campaign) $exp $freq $ens"
				echo "($campaign) $pub_head_dir/$thisModel/$thisExp/$path_mid/$freq/$ens/v1"
			done
		done
	done
done


